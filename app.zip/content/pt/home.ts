export const homeContent = {
    heroTitle: 'YugNex AI',
    tagline: 'A Primeira Inteligência de Engenharia de Software Persistente do Mundo.',
    subline: 'Da ideia à produção com memória, raciocínio e continuidade.',
}

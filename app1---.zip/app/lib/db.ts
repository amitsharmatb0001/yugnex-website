import mysql from 'mysql2/promise';

export const db = mysql.createPool({
  host: process.env.DB_HOST || '127.0.0.1',
  user: process.env.DB_USER || 'root',
  password: process.env.DB_PASSWORD || '', // ← Force empty string
  database: process.env.DB_NAME || 'yugnex_prod',
  waitForConnections: true,
  connectionLimit: 10,
  // Add this for local development:
  insecureAuth: true, // Allows empty passwords
});
export const homeContent = {
    heroTitle: 'YugNex AI',
    tagline: 'The Worlds First Persistent Software Engineering Intelligence.',
  subline: 'From idea to production with memory, reasoning, and continuity. Built in India for the world.',
}

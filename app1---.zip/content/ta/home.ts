import { HomeContent } from '@/app/lib/contentTypes'

export const homeContent: HomeContent = {
    heroTitle: "யுக்நெக்ஸ் AI",
    tagline: "அடிப்படை AI அமைப்புகள் ஆய்வகம் · இந்தியாவிலிருந்து உலகிற்கு",
    subline: "உண்மையாகவே புரிந்துகொள்ளும், காரணம் கூறும் மற்றும் ஒத்துழைக்கும் தன்னாட்சி மென்பொருள் பொறியியல் தளங்களை நாங்கள் உருவாக்குகிறோம்",
    banner: "தனியார் ஆராய்ச்சி & மேம்பாட்டு கட்டம் • 2027 துவக்கம்",
    credentials: "DPIIT Recognized (DIPP234393) • Founded 2025 • Deep Research Mode"
}

export const homeContent = {
  heroTitle: 'YugNex AI',
  tagline: 'The World’s First Persistent Software Engineering Intelligence.',
  subline: 'From idea to production, with memory, reasoning, and continuity across the full software lifecycle.',
  banner: 'Currently in foundational research and core system development.',
  credentials: 'DPIIT Recognized Startup · Patent Pending · Built in India · Global Standards',
}

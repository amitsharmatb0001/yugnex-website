export const faqContent = [
    {
        question: "Kab try kar sakte hain?",
        answer: "Hum advanced prototype phase mein hain aur is saal launch plan hai. Early access ke liye waitlist join karein."
    },
    {
        question: "Kya yeh ek aur code completion tool hai?",
        answer: "Nahi. Hum aisi systems bana rahe hain jo poore software architecture ko samajhti aur reason karti hain."
    },
    {
        question: "Yeh possible kyun hai?",
        answer: "Kyunki AI capabilities us level tak pahunch gayi hain jahan true software reasoning feasible hai. Humne core innovations par patents file kiye hain. Sawal execution ka hai, possibility ka nahi."
    },
    {
        question: "Kya aap hiring kar rahe hain?",
        answer: "Abhi core R&D par focus hai. Future opportunities announce ki jayengi."
    },
    {
        question: "Cursor, GitHub Copilot ya dusre AI coding tools se kya different hai?",
        answer: "Woh assistance tools hain. Hum autonomous engineering systems bana rahe hain. Farak hai reasoning vs. generation ka."
    },
    {
        question: "Kya yeh developers ko replace kar dega?",
        answer: "Nahi. Software engineering mein human judgment, creativity aur context chahiye jo AI replace nahi kar sakta. Hamara platform engineers ko augment karta hai, system understanding ka cognitive load handle karta hai taaki aap higher-level decisions par focus kar sakein."
    },
    {
        question: "Proprietary codebases ko kaise handle karta hai?",
        answer: "Aapka code aapka hai. Hum on-premise aur private cloud deployment ke liye bana rahe hain full data sovereignty ke saath. Koi bhi code aapki infrastructure se bahar nahi jata aapki explicit permission ke bina."
    },
    {
        question: "Kaun se languages/frameworks support karta hai?",
        answer: "Hum sabse zyada use hone wale languages aur frameworks se shuru kar rahe hain. Specific support matrix launch ke kareeb announce hoga."
    },
    {
        question: "Kya legacy systems ke saath kaam kar sakta hai?",
        answer: "Haan. Actually, minimal documentation wale legacy systems mein architectural understanding sabse valuable hota hai. Platform code se hi architectural intent reconstruct karta hai."
    },
    {
        question: "Learning curve kaisa hai?",
        answer: "Agar aap apna current IDE use kar sakte hain, toh aap hamara platform bhi use kar sakte hain. Hum zero friction adoption ke liye design kar rahe hain."
    },
    {
        question: "Kya mera code training ke liye use hota hai?",
        answer: "Nahi. Aapka code kabhi training ke liye use nahi hota. Platform aapke specific codebase ko analyze karta hai uske unique architecture ko samajhne ke liye—aapki IP completely private rehti hai."
    },
    {
        question: "AI pair programming se kya different hai?",
        answer: "AI pair programming tools predict karte hain aap kya type karenge. Hum samajhte hain aapke changes puri system par kya effect dalenge. Yeh hai tactical assistance aur strategic understanding ka farak."
    },
    {
        question: "Exactly kab launch hoga?",
        answer: "2026, jab production use ke liye ready hoga. Hum demos ke saath market mein rush nahi kar rahe—hum aisi systems bana rahe hain jo real-world conditions mein reliably kaam karein."
    }
]
